import React, { Component } from 'react';
import { Route } from 'react-router-dom';
import Login from './components/Login';
import Register from './components/Register';
import DataDetails from './components/DataDetails';
import PageDetails from './components/PageDetails';
import './App.css';
import 'bootstrap/dist/css/bootstrap.min.css';
import 'bootstrap/dist/js/bootstrap.min';

class App extends Component {
  render() {
    return (
      
      <div className="container">
        <Route exact path="/" component={Login} />
        <Route path="/register" component={Register} />
       	<Route path="/datadetails" component={DataDetails} />
		<Route path="/pagedetails" component={PageDetails} />
      </div>
    );
  }
}

export default App;
