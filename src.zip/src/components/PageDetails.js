import React, { Component } from 'react'
import { MDBDataTable } from 'mdbreact';
import axios from 'axios';
var cors = require('cors');

//var app = express()

class PageDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
	   
      places: []
    };
  }

     
  componentDidMount() {
	  
	  const disp = this.props.location.pathname;
const tid = disp.replace('/pagedetails/', '');
console.log(tid);
	   const proxyurl = "https://cors-anywhere.herokuapp.com/";
    axios.get(proxyurl +"https://roadtrippers.herokuapp.com/api/v1/place/"+tid, {   method:'GET',
            mode: 'cors',
            headers:{
                'Access-Control-Allow-Origin':'*'
            },
        })
      .then(res => {
        const places = res.data;
        this.setState({ places });
      })
  }

  render() {
    return (
	 <div>  
     <div class="row">
<div class="col-xs-12">
      <ul>
        { this.state.places.map(plac => 
		<div class="col-md-6">	  
	  <div class="info-box">
		<li>{plac.name}<br /><img src={plac.cover} width="350px" /></li> 
		</div></div>
		)}
      </ul></div></div>
		
          </div>
    )
  }
}

export default PageDetails;