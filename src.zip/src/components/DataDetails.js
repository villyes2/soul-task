import React, { Component } from 'react'
import { MDBDataTable } from 'mdbreact';
import axios from 'axios';
var cors = require('cors')
//var app = express()

class DataDetails extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      error: null,
      isLoaded: false,
      places: []
    };
  }

  componentDidMount() {
	  const proxyurl = "https://cors-anywhere.herokuapp.com/";
   fetch(proxyurl +"https://roadtrippers.herokuapp.com/api/v1/places/", {   method:'GET',
            mode: 'cors',
            headers:{
                'Access-Control-Allow-Origin':'*'
            },
        })
      .then(res => res.json())
      .then(
        (result) => {
          this.setState({
            isLoaded: true,
            places: result.places
          });
        },
        
        (error) => {
          this.setState({
            isLoaded: true,
            error
          });
        }
      )
  
  }

  render() {
    const { error, isLoaded, places } = this.state;
	console.log(places);
    if (error) {
	//	console.log(places);
      return <div>Error: {error.message}</div>;
    } else if (!isLoaded) {
      return <div>Loading...</div>;
    } else {
      return (
	  <div>  
     <div class="row">
<div class="col-xs-12">
        <ul>
          {places.map(place => (
 
      
		  <div class="col-md-6">	  
	  <div class="info-box">
            <li key={place.name}>
            <a href={"pagedetails/" +place.id} onClick={place.id}> {place.name} <img src={place.cover} width="170px" /></a>
			  
            </li>
			</div></div>
          
          ))}
        </ul></div></div>
		
          </div>
      );
    }
  }
}

export default DataDetails;